﻿define("epi-ecf-ui/widget/overlay/CommerceMediaCollection", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",

// EPi CMS
    "epi-cms/widget/overlay/ItemCollection",

// EPi Commerce
    "../../component/CommerceMediaItemModel"
], function (
// Dojo
    declare,
    lang,
    when,

// EPi CMS
    ItemCollectionOverlay,

// EPi Commerce
    CommerceMediaItemModel
) {
    return declare([ItemCollectionOverlay], {
        // summary:
        //      The new overlay item for commerce media collection.
        // module:
        //      "epi-ecf-ui/widget/overlay/CommerceMediaCollection"
        // description:
        //      Drag and drop media to create new asset item (at the very top)
        // tags:
        //    public

        // modelType: [public] String
        //      Used to inject model for this.
        modelType: "epi-ecf-ui/contentediting/editors/model/CommerceMediaCollectionEditorModel",

        onDrop: function (target, value) {
            // summary:
            //      Handles onDrop and add new value to model then raise onValueChange event to save this.
            // target: [Object]
            //      The dnd target.
            // value: [Object || Array]
            //      The dnd data.
            // tags:
            //      private

            // insert new item at the very top
            var topItem = null,
                modelData = this.model.get("items");
            if (modelData) {
                topItem = modelData[0];
            }
            when(this.model.addItem(value, topItem, true), lang.hitch(this, function () {
                var items = this.model.get("data");
                this.onValueChange({
                    propertyName: this.name,
                    value: items
                });
            }));
        },

        _setupModel: function (/*Object*/data) {
            // summary:
            //      setup the viewmodel with latest value
            // tag:
            //      public override

            require([this.modelType], lang.hitch(this, function (modelClass) {
                var modelData = { };
                // set itemModel as Commerce media item model
                modelData.itemModelType = CommerceMediaItemModel;
                // set itemType as Commerce media
                modelData.itemType = "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.CommerceMediaModel";
                this.model = new modelClass(modelData, this.modelParams);
                this.model.set("data", data); // set model data
            }));
        },

        _setupAllowedTypes: function () {
            // summary:
            //      Setup the allowed types for drag and drop
            // tags:
            //      Protected override

            var converterKey = this.modelParams.itemConverterKey,
                customTypeIdentifier = this.modelParams.customTypeIdentifier;

            this.allowedDndTypes = this.allowedDndTypes || [];

            if (converterKey) {
                customTypeIdentifier = customTypeIdentifier + "." + converterKey;
            }

            if (customTypeIdentifier) {
                // add this commerce media type to the list of allowed DnD type
                this.allowedDndTypes.unshift(customTypeIdentifier);
            }
        }
    });
});
