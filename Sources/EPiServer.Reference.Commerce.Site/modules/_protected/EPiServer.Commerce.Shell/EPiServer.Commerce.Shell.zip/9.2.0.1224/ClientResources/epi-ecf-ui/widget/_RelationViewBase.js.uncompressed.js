﻿define("epi-ecf-ui/widget/_RelationViewBase", [
// dojo
    "dojo/aspect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/Evented",
    "dojo/topic",
    "dojo/dom-geometry",
    "dojo/dom-style",
    "dojo/_base/window",

// dijit
    "dijit/layout/_LayoutWidget",

// cms
    "epi-cms/widget/Breadcrumb",
    "epi-cms/widget/BreadcrumbCurrentItem",

// commerce
    "./BackToPreviousViewNotification"

], function (
// dojo
    aspect,
    declare,
    lang,
    array,
    Evented,
    topic,
    domGeometry,
    domStyle,
    window,

// dijit
    _LayoutWidget,

// CMS
    Breadcrumb,
    BreadcrumbCurrentItem,

// commerce
    BackToPreviousViewNotification
) {

    return declare([_LayoutWidget], {
        // summary:
        //    Represents the widget to edit relations and assiciations.
        // tags:
        //    public

        // Classes inheriting from this class needs to specify a dijit/layout/ContentPane.
        contentPane: null,

        _backToPreviousViewNotification: null,

        postCreate: function(){
            this.inherited(arguments);
            this._backToPreviousViewNotification = new BackToPreviousViewNotification();
            this.own(
                this._backToPreviousViewNotification.watch("notification", lang.hitch(this, this._defaultNotificationWatchHandler))
            );
        },

        _defaultNotificationWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Add/remove notification to/from notification bar
            // tags:
            //      private

            if (oldValue) {
                this.notificationBar.remove(oldValue);
            }

            if (newValue && newValue.content) {
                this.notificationBar.add(newValue);
            }
        },

        updateView: function (data, context) {
            // summary:
            //		Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //		protected

            this.toolbar.update({
                currentContext: context,
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });

            this._backToPreviousViewNotification.showNotification();
        },

        resize: function () {
            // summary:
            //		Resize this widget to the given dimensions.
            // tags:
            //		protected
            this.inherited(arguments);

            // make the grid 100% height
            var top = domGeometry.position(this.contentPane.domNode).y;
            var bodyHeight = domGeometry.position(window.body()).h;
            domStyle.set(this.contentPane.domNode, "height", (bodyHeight - top) + "px");
        }
    });
});
