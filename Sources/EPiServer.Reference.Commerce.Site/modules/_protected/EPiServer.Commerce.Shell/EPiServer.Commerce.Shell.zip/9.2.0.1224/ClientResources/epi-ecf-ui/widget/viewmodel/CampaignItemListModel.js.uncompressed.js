require({cache:{
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignNameColumn.html':"﻿<div>\n    <h1>${name}</h1>\n    <h2>${group}</h2>\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignOrdersColumn.html':"﻿<h1>${nrOfOrders}</h1>\n<h2>${text}</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignStatusColumn.html':"﻿<h1>${statusLabel}</h1>\n<h2>${fromDate} - ${toDate}</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionNameColumn.html':"﻿<h3>${name}</h3>\n<span class=\"dijitInline dijitReset dijitIcon epi-objectIcon ${iconClass}\"></span> <span class=\"epi-secondaryText\">${group}</span>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionOrdersColumn.html':"﻿<h2>\n    <h3>${nrOfOrders}</h3>\n    <span class=\"epi-secondaryText\">${text}</span>\n</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionStatusColumn.html':"﻿<div class=\"epi-grid-column--centered\">\n    ${text} ${date}\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/RedeemedValueColumn.html':"﻿<h1>${redeemedValueAmount}</h1>\n<h2>${redeemedValue}</h2>"}});
﻿define("epi-ecf-ui/widget/viewmodel/CampaignItemListModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/string",

//dgrid
    "dgrid/tree",

// epi
    "epi/datetime",
    "epi/shell/command/_Command",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/dgrid/util/misc",
    "epi/shell/TypeDescriptorManager",

// epi-cms
    "epi-cms/component/command/ChangeContext",
    "epi-cms/command/NewContent",

// epi-ecf-ui
    "../../MarketingUtils",
    "../DeleteCampaignItemDialog",

// resources
    "epi/i18n!epi/nls/commerce.widget.campaignitemlist",
    "epi/i18n!epi/nls/episerver.shared",
    "dojo/text!./templates/CampaignNameColumn.html",
    "dojo/text!./templates/CampaignOrdersColumn.html",
    "dojo/text!./templates/CampaignStatusColumn.html",
    "dojo/text!./templates/PromotionNameColumn.html",
    "dojo/text!./templates/PromotionOrdersColumn.html",
    "dojo/text!./templates/PromotionStatusColumn.html",
    "dojo/text!./templates/RedeemedValueColumn.html"
],

function (
// dojo
    array,
    declare,
    lang,
    domClass,
    domConstruct,
    dojoString,

//dgrid
    tree,

// epi
    epiDate,
    _Command,
    _CommandProviderMixin,
    shellMisc,
    TypeDescriptorManager,

// epi-cms
    ChangeContext,
    NewContent,

// epi-ecf-ui
    MarketingUtils,
    DeleteCampaignItemDialog,

// resources
    resources,
    sharedResources,
    campaignNameColumnTemplate,
    campaignOrdersColumnTemplate,
    campaignStatusColumnTemplate,
    promotionNameColumnTemplate,
    promotionOrdersColumnTemplate,
    promotionStatusColumnTemplate,
    redeemedValueColumnTemplate
) {

    return declare([_CommandProviderMixin], {

        // itemType: Object
        //      Types used on marketing objects
        itemType: {
            notSet: 0,
            promotion: 1,
            campaign: 2
        },

        postscript: function () {
            this.inherited(arguments);
            this._setupCommands();
        },

        _setupCommands: function () {
            var deleteCommand = this.createDeleteCommand(true);
            var changeContext = new ChangeContext({
                category: "context",
                forceContextChange: true
            });

            var createDiscountCommand = new NewContent({
                category: "context",
                contentType: MarketingUtils.contentTypeIdentifier.promotionData,
                label: resources.createpromotion
            });
            //do you want to add more create commands here? consider refactoring to use CreateCommandsMixin
            this.set("commands", [changeContext, createDiscountCommand, deleteCommand]);
        },

        createDeleteCommand: function (useContextMenu) {
            var deleteCommand = new _Command({
                store: this.store,
                iconClass: "epi-iconClose",
                label: sharedResources.action.deletelabel,
                canExecute: false,
                _onModelChange: function () {
                    this.set("canExecute", !!this.get("model"));
                },
                _execute: function () {
                    var dialog = new DeleteCampaignItemDialog({
                        contentData: this.get("model"),
                        store: this.store
                    });
                    dialog.show();
                }
            });

            if (useContextMenu) {
                deleteCommand.set("category", "context");
            }
            return deleteCommand;
        },

        updateCommandModel: function (model) {
            var commands = this.get("commands");
            array.forEach(commands, function (command) {
                command.set("model", model);
            });
        },

        // summary:
        //      Model for CampaignItemList.
        // tags:
        //      public
        createGridColumns: function () {
            var columns = {
                expando: tree({
                    label: "",
                    sortable: false,
                    shouldExpand: function () { return true; },
                    renderExpando: function (level, hasChildren, expanded, object) {
                        // summary:
                        //      We override the default expando rendering to get rid of the
                        //      default indentation.

                        var node = domConstruct.create("div");
                        //"dgrid-expando-icon" is needed for click events
                        domClass.add(node, "dgrid-expando-icon");
                        node.innerHTML = "&nbsp;";
                        return node;
                    }
                }),
                name: {
                    className: "epi-grid--40",
                    get: lang.hitch(this, this._getNameModel),
                    formatter: lang.hitch(this, this._getNameHtml)
                },
                status: {
                    className: "epi-grid-column--centered",
                    get: lang.hitch(this, this._getStatusModel),
                    formatter: lang.hitch(this, this._getStatusHtml)
                },
                orders: {
                    className: "epi-grid--15",
                    get: function (campaignItem) {
                        return { typeIdentifier: campaignItem.typeIdentifier, orders: campaignItem.properties.redemptions };
                    },
                    formatter: lang.hitch(this, this._getOrdersHtml),
                    renderCell: lang.hitch(this, function (item, value, node, options) {
                        domClass.add(node, "epi-grid-column--centered");
                        node.innerHTML = this._getOrdersHtml(value);
                    })
                },
                revenue: {
                    className: "epi-grid--15",
                    get: function (campaignItem) {
                        return { typeIdentifier: campaignItem.typeIdentifier, revenue: campaignItem.properties.redeemedValue };
                    },
                    formatter: lang.hitch(this, this._getRevenueValueHtml),
                    renderCell: lang.hitch(this, function (item, value, node, options) {
                        domClass.add(node, "epi-grid-column--centered");
                        node.innerHTML = this._getRevenueValueHtml(value);
                    })
                }
            };

            return columns;
        },

        getItemClass: function (campaignItem) {
            if (this._getItemType(campaignItem.typeIdentifier) === this.itemType.campaign) {
                return "epi-card-grid__heading";
            } else {
                return "epi-card-grid__content";
            }
        },

        getItemStatusClass: function (campaignItem) {
            var itemType = this._getItemType(campaignItem.typeIdentifier);
            var itemStatus = campaignItem.properties.status;

            if (itemType === this.itemType.campaign) {
                var campaignClass = "epi-card-grid__heading--";
                switch (itemStatus) {
                    case MarketingUtils.status.pending:
                        return campaignClass + "pending";
                    case MarketingUtils.status.active:
                        return campaignClass + "active";
                    case MarketingUtils.status.expired:
                        return campaignClass + "expired";
                    default:
                        return campaignClass + "inactive";
                }
            } else if (itemType === this.itemType.promotion) {
                var promotionClass = "epi-card-grid__content--";

                if (itemStatus === MarketingUtils.status.active) {
                    return promotionClass + "active";
                }
                if (itemStatus === MarketingUtils.status.pending) {
                    return promotionClass + "pending";
                }
                return promotionClass + "inactive";
            }
        },

        _getItemType: function (typeIdentifier) {
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.salesCampaign)) {
                return this.itemType.campaign;
            }
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.promotionData)) {
                return this.itemType.promotion;
            }
            return this.itemType.notSet;
        },

        _getStatusHtml: function (statusColumnModel) {
            if (this._getItemType(statusColumnModel.typeIdentifier) === this.itemType.campaign) {
                return dojoString.substitute(campaignStatusColumnTemplate, {
                    statusLabel: resources.status[statusColumnModel.statusLabelKey],
                    fromDate: epiDate.toUserFriendlyString(statusColumnModel.validFrom),
                    toDate: epiDate.toUserFriendlyString(statusColumnModel.validUntil)
                });
            }

            var promotionStatus = statusColumnModel.status;
            var campaignStatus = statusColumnModel.campaignStatus;
            
            if (promotionStatus === MarketingUtils.status.inactive) {
                return resources.status.inactive;
            }

            if (statusColumnModel.followsCampaignSchedule || campaignStatus === MarketingUtils.status.expired || campaignStatus === MarketingUtils.status.inactive) {
                return "";
            }

            if (promotionStatus === MarketingUtils.status.active) {
                return dojoString.substitute(promotionStatusColumnTemplate, {
                    text: epiDate.toUserFriendlyString(statusColumnModel.validFrom) + " - ",
                    date: epiDate.toUserFriendlyString(statusColumnModel.validUntil)
                });
            }

            return dojoString.substitute(promotionStatusColumnTemplate, {
                date: epiDate.toUserFriendlyString(this._getDate(statusColumnModel)),
                text: this._getDateText(statusColumnModel)
            });
        },

        _getStatusModel: function (campaignItem) {
            var validFrom = new Date(campaignItem.properties.validFrom);
            var validUntil = new Date(campaignItem.properties.validUntil);

            return {
                status: campaignItem.properties.status,
                statusLabelKey: this._getStatus(campaignItem),
                validFrom: validFrom,
                validUntil: validUntil,
                typeIdentifier: campaignItem.typeIdentifier,
                campaignStatus: campaignItem.properties.campaignStatus,
                followsCampaignSchedule: campaignItem.properties.followsCampaignSchedule
            };
        },

        _getStatus: function (campaignItem) {
            return MarketingUtils.getStatusString(campaignItem.properties.status);
        },

        _getDate: function (statusColumnModel) {

            if (statusColumnModel.validFrom > new Date()) {
                return statusColumnModel.validFrom;
            }

            return statusColumnModel.validUntil;
        },

        _getDateText: function (statusColumnModel) {
            var validFrom = statusColumnModel.validFrom,
                validUntil = statusColumnModel.validUntil,
                now = new Date();

            if (validFrom < now && validUntil > now) { // Currently active
                return resources.datetext.active;
            }

            if (validFrom > now) { // Pending
                return resources.datetext.pending;
            }

            return resources.datetext.expired; // Expired
        },

        _getOrdersHtml: function (orderColumnModel) {
            var text = resources.orders;
            var template = promotionOrdersColumnTemplate;

            if (this._getItemType(orderColumnModel.typeIdentifier) === this.itemType.campaign) {
                text = resources.totalorders;
                template = campaignOrdersColumnTemplate;
            }

            return dojoString.substitute(template, {
                text: text,
                nrOfOrders: orderColumnModel.orders
            });
        },

        _getRevenueValueHtml: function (revenueColumnModel) {

            if (this._getItemType(revenueColumnModel.typeIdentifier) !== this.itemType.campaign) {
                return "";
            }

            return dojoString.substitute(redeemedValueColumnTemplate, {
                redeemedValue: resources.redeemedvalue,
                redeemedValueAmount: revenueColumnModel.revenue
            });
        },

        _getNameHtml: function (nameColumnModel) {
            var template = promotionNameColumnTemplate;

            if (this._getItemType(nameColumnModel.typeIdentifier) === this.itemType.campaign) {
                template = campaignNameColumnTemplate;
            }

            return dojoString.substitute(template, {
                name: shellMisc.htmlEncode(nameColumnModel.name),
                group: (!!nameColumnModel.group) ? resources.group[nameColumnModel.group] : resources.campaign,
                iconClass: TypeDescriptorManager.getValue(nameColumnModel.typeIdentifier, "iconClass")
            });
        },

        _getNameModel: function (campaignItem) {
            return {
                typeIdentifier: campaignItem.typeIdentifier,
                name: campaignItem.name,
                group: this._getPromotionGroup(campaignItem.typeIdentifier)
            };
        },

        _getPromotionGroup: function (typeIdentifier) {
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.entryPromotion)) {
                return "entry";
            }
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.orderPromotion)) {
                return "order";
            }
            if (TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, MarketingUtils.contentTypeIdentifier.shippingPromotion)) {
                return "shipping";
            }
            return null;
        }
    });
});