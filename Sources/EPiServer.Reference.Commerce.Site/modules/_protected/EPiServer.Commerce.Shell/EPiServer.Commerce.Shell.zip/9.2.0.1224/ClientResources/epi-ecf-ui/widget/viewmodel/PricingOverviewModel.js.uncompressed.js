﻿define("epi-ecf-ui/widget/viewmodel/PricingOverviewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/Stateful",
    // EPi Framework
    "epi/dependency",
    "epi/datetime",
    "epi/shell/_StatefulGetterSetterMixin"
], function (
// dojo
    declare,
    lang,
    when,
    Stateful,
    // EPi Framework
    dependency,
    epiDate,
    _StatefulGetterSetterMixin
) {
    return declare([Stateful, _StatefulGetterSetterMixin], {
        // summary:
        //    Represents the Pricing overview widget's model.
        // model:
        //    "epi-ecf-ui/widget/viewmodel/PricingOverviewModel"
        // tags:
        //    public

        _customerGroupStore: null,

        _contentStructureStore: null,

        content: null,

        postscript: function () {
            // summary:
            //      Post properties mixin handler.
            // description:
            //      Set up model and resource for template binding.
            // tags:
            //      protected

            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._customerGroupStore = this._customerGroupStore || registry.get("epi.commerce.customergroup");
            this._contentStructureStore = this._contentStructureStore || registry.get("epi.cms.content.light");
        },

        populateData: function () {
            // summary:
            //      Loads data.
            // tags:
            //      protected

            when(this._customerGroupStore.query(), lang.hitch(this, function (customerGroupList) {
                this.set("customerGroups", customerGroupList);
            }));
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.

            this._set("value", value);

            when(this._contentStructureStore.get(value), lang.hitch(this, function (content) {
                this.set("content", content);
            }));
        },

        getDefaultPrice: function () {
            // summary:
            //      Get default price of the current content data.
            // tags:
            //      protected

            if (!this.content) {
                return null;
            }

            var priceTypeAll = 0;
            var priceTypePriceGroup = 2;

            return {
                contentLink: this.content.contentLink,
                name: this.content.name,
                code: this.content.properties.code,
                minQuantity: 0
            };
        }
    });
});
