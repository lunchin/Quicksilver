﻿define("epi-ecf-ui/widget/BackToPreviousViewNotification", [
    "dojo/_base/declare",
    "dojo/dom-construct",
    "dojo/Stateful",
    "dojo/topic",
    "epi-cms/command/BackCommand",
    "epi/i18n!epi/cms/nls/commerce.widget.backtodefaultview"
],function(
    declare,
    domConstruct,
    Stateful,
    topic,
    BackCommand,
    resources
){
    return declare([Stateful], {

        command: null,

        notification: null,

        constructor: function(){
            this.command = new BackCommand({
                canExecute: true,
                _execute: function(){
                    //we're overriding the default back command execute to just switch back to the previously used widget.
                    topic.publish("/epi/shell/action/changeview/back", true/* force the widget to reload, in order to reflect changes if any. */);
                },
                _onModelChange: function() {/*I don't care about the model.*/}
            });
        },

        showNotification: function(){
            var notificationText = domConstruct.create("div", {
                innerHTML: resources.notificationtext
            });

            this.set("notification", {
                content: notificationText,
                commands: [this.command]
            });
        }
    });
});