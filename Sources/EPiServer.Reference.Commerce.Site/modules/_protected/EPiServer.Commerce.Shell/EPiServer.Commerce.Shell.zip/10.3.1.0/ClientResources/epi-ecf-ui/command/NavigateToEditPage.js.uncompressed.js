﻿define("epi-ecf-ui/command/NavigateToEditPage", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "epi/dependency",
    "epi/shell/_ContextMixin",
    "epi-cms/component/command/ChangeContext"
],

function (
    declare,
    lang,
    when,
    dependency,
    _ContextMixin,
    ChangeContext
) {

    return declare([ChangeContext, _ContextMixin], {
        // summary:
        //      A command that forces browser to navigate to edit content page instead of only changing context.
        //
        // tags:
        //      public

        _hashWrapper: null,

        _contextStore: null,

        postscript: function () {
            this.inherited(arguments);
            this._contextStore = this._contextStore || dependency.resolve("epi.storeregistry").get("epi.shell.context");
            this._hashWrapper = this._hashWrapper || dependency.resolve("epi.shell.HashWrapper");
        },

        _execute: function () {
            // summary:
            //		Executes this command; open the edit content page in Commerce view.
            // tags:
            //		protected

            when(this._contextStore.query({ uri: this.model.uri })).then(lang.hitch(this, function (context) {
                this._navigateTo(context.fullHomeUrl + "#" + this._hashWrapper.extractHash(context));
            }));
        },

        _navigateTo: function (url) {
            window.location = url;
        }
    });
});
